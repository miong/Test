
public class ByCab implements Strategy{

	public String goToAirport(){
		return "I go to the airport by Cab !!";
	}
	
}
