public enum Context {

	ALONE,
	FASTEST,
	CHEAPEST

}
