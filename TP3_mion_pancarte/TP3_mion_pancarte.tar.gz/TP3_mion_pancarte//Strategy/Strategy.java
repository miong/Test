interface Strategy {

	public String goToAirport();
}
