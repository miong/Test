
public class ByCar implements Strategy{

	public String goToAirport(){
		return "I go to the airport by car !!";
	}
	
}
