/*********************************************************
 * test_TP3
 * memento
 * ClientInterface.java	
 * (c)test_TP3 on 15 nov. 2013 17:35:50
 * By Bubul
 * Update 15 nov. 2013 17:35:50
*********************************************************/


/**
 * @author Bubul
 *
 */
public interface ClientInterface {

	public int save();
	
	public void restore(int ID);
	
}
