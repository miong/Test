

public interface ClientInterface {
	
	public boolean sendMessage(String s);
	
	public String readResponse();
	
}
